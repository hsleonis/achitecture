<?php
	use frontend\models\MenuPageRels;
?>

<div class="menu_style_1">
	<?php echo MenuPageRels::getHierarchy_page(); ?>
</div>