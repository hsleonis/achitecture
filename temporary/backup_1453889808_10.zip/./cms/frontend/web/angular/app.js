/*
 APP JS v1.0.1
 (c) 2015 DCASTALIA. http://dcastalia.com
 License: GPL v3
*/

// App
var app = angular.module('homes', ['ngAnimate', 'ngRoute', 'ngStorage', 'ui.router']).run(function($templateCache, $http) {
    /*$http.get('views/productList.html', {
        cache: $templateCache
    });*/
});