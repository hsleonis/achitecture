<?php return [
'adminEmail' => 'shimul@dcastalia.com',
'contact_email' => 'shahriar@dcastalia.com',
'backend.theme' => 'quarca',
'frontend.theme' => 'personal',
'site_title' => 'EMRAN & ASSOCIATES.  ',
'facebook' => 'Facebook link',
'twitter' => 'Twitter link',
'linkedin' => 'LinkedIn link',
'copyright_text' => '© ARCHITECT EMRAN & ASSOCIATES. 2015   ',
'user.passwordResetTokenExpire' => '3600',
'admin_email' => 'shahriar@dcastalia.com',
'editor' => 'full',
'setup.status' => 'Installed'
];