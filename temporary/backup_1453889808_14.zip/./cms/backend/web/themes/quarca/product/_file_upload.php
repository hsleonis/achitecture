<tr class="product_file_<?= $model->id; ?>">
	<td><?= $model->title; ?></td>
	<td><?= $model->file_name; ?></td>
	<td><a href="" class="btn btn-xs btn-primary file_remove_btn"  data_id="<?php echo $model->id; ?>" >Remove</a></td>
</tr>