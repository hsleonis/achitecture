$(document).delegate('.delete', 'click', function() { 
    alert('ok');
});