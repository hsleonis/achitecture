<?php

echo 'ok
require "browse.php";';
?>