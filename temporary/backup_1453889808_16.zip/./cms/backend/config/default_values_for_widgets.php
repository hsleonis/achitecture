<?php
\Yii::$container->set('yii\grid\GridView', [
    'tableOptions' => [
        'class' => 'table table-striped no-margin-bottom',
    ],
]);

/*\Yii::$container->set('yii\grid\GridView', [
    'tableOptions' => [
        'class' => 'table table-striped no-margin-bottom',
    ],
]);*/